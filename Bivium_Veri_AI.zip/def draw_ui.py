def draw_ui(frame):
    global PHASE, USER_SPEECH, mic_volume, audio_history
    
    # Визначаємо розміри кадру для динамічних координат
    h, w, _ = frame.shape
    
    # Створюємо чисте Pillow зображення для тексту (з прозорістю)
    img_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    
    # Завантажуємо шрифт (спробуй знайти arial.ttf на Windows, він зазвичай тут: C:\Windows\Fonts)
    # Якщо ні, залиш стандартний.
    try: font = ImageFont.truetype("arial.ttf", 24)
    except: font = ImageFont.load_default()

    # --- Текст Олени (Зверху) ---
    # fill=(B, G, R) - тут Яскраво-зелений
    # fill=(255, 255, 0) - Жовтий (для Олени)
    text_elena = f"STATUS: {PHASE}"
    draw.text((30, 30), text_elena, font=font, fill=(0, 255, 0))

    # --- Текст Користувача (Знизу) ---
    # fill=(255, 255, 255) - Білий
    text_user = f"YOU: {USER_SPEECH}"
    draw.text((30, h - 60), text_user, font=font, fill=(255, 255, 255))
    
    # --- Підказка (Центр, знизу) ---
    if PHASE == "ОЧІКУВАННЯ":
        prompt_text = "HOLD 'S' TO TALK"
        # Розраховуємо центр
        # Отримуємо координати прямокутника тексту:(left, top, right, bottom)
        bbox = draw.textbbox((0, 0), prompt_text, font=font)
        tw = bbox[2] - bbox[0] # Ширина
        th = bbox[3] - bbox[1] # Висота
        draw.text(((w - tw) // 2, h - 100), prompt_text, font=font, fill=(0, 255, 255))

    # Конвертуємо назад в OpenCV формат
    frame = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    
    # --- Осцилограма та індикатор гучності ---
    # (Вони вже працюють, залиш як було)
    cv2.rectangle(frame, (15, h-50), (35, h-200), (30, 30, 30), -1)
    cv2.rectangle(frame, (15, h-50), (35, h-50-int(mic_volume*150)), (0, 255, 255), -1)
    for i in range(1, len(audio_history)):
        cv2.line(frame, (45+(i-1)*3, int(h-125-(audio_history[i-1]*40))), 
                 (45+i*3, int(h-125-(audio_history[i]*40))), (0, 255, 255), 1)
        
    return frame