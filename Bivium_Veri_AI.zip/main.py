import os
import cv2
import time
import threading
import pyttsx3
import numpy as np
import sounddevice as sd
import speech_recognition as sr
from PIL import Image, ImageDraw, ImageFont
from google import genai
from dotenv import load_dotenv

# --- ІНІЦІАЛІЗАЦІЯ ---
load_dotenv()
client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

MODELS = {
    "1": "gemini-2.0-flash",
    "2": "gemini-1.5-pro",
    "3": "gemini-2.0-flash-lite-preview" 
}
CURRENT_MODEL = MODELS["1"] 

# --- ГЛОБАЛЬНІ СТАТУСИ ---
STRESS_LEVEL = 0
PHASE = "ОЧІКУВАННЯ"
USER_SPEECH = ""
mic_volume = 0
mic_monitor_active = True
speech_lock = threading.Lock()
# Масив для зберігання останніх 50 значень гучності (для малювання хвилі)
audio_history = [0] * 50

# --- СИСТЕМА ГОЛОСУ ---
engine = pyttsx3.init()
voices = engine.getProperty('voices')
# Індекс 7 зазвичай для української, якщо немає - беремо 0
engine.setProperty('voice', voices[7].id if len(voices) > 7 else voices[0].id)
engine.setProperty('rate', 175)

def speak(text):
    def run_tts():
        with speech_lock:
            try:
                engine.say(text)
                engine.runAndWait()
            except Exception as e:
                print(f"Помилка голосу: {e}")
    threading.Thread(target=run_tts, daemon=True).start()

# --- АУДІО МОНІТОР ---
def audio_volume_monitor():
    # Додаємо audio_history у global, щоб callback міг його змінювати
    global mic_volume, mic_monitor_active, audio_history 
    
    def callback(indata, frames, time, status):
        # Використовуємо глобальний список всередині callback
        global audio_history 
        
        if mic_monitor_active:
            # Обчислюємо нормалізацію звуку
            volume_norm = np.linalg.norm(indata) * 10
            v = min(volume_norm / 100, 1.0)
            
            globals()['mic_volume'] = v
            
            # Оновлюємо історію для маленької осцилограми
            audio_history.append(v)
            if len(audio_history) > 50:
                audio_history.pop(0)
        else:
            globals()['mic_volume'] = 0
            # Коли мікрофон "заморожений", малюємо пряму лінію (нулі)
            audio_history.append(0)
            if len(audio_history) > 50:
                audio_history.pop(0)
                
    try:
        # Вказуємо параметри пристрою, якщо раніше були проблеми зі звуком
        with sd.InputStream(callback=callback, channels=1):
            while True:
                sd.sleep(100)
    except Exception as e:
        print(f"Помилка аудіо-монітора: {e}")

# --- ВІЗУАЛІЗАЦІЯ (HUD) ---
def draw_ui(frame):
    global STRESS_LEVEL, PHASE, USER_SPEECH, mic_volume, CURRENT_MODEL
    h, w, _ = frame.shape
    
    # 1. Напівпрозоре меню команд
    overlay = frame.copy()
    cv2.rectangle(overlay, (w - 260, 10), (w - 10, 200), (20, 20, 20), -1)
    alpha = 0.6 
    cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)

    commands = [
        f"MODEL: {CURRENT_MODEL.split('/')[-1]}",
        "-------------------",
        "S - START SESSION",
        "R - REBOOT SYSTEM",
        "X - STOP AGENT",
        "T - TEST CORE",
        "1-3 - CHANGE MODEL"
    ]
    
    for i, text in enumerate(commands):
        cv2.putText(frame, text, (w - 250, 40 + (i * 25)), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)

    # 2. PIL для української мови
    img_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    
    try:
        font = ImageFont.truetype("arial.ttf", 24)
        small_font = ImageFont.truetype("arial.ttf", 18)
    except:
        font = ImageFont.load_default()
        small_font = ImageFont.load_default()

    status_color = (0, 255, 0) if STRESS_LEVEL < 50 else (255, 0, 0)
    draw.text((30, 30), f"СТАТУС: {PHASE}", font=font, fill=status_color)
    draw.text((30, h - 60), f"ВИ: {USER_SPEECH}", font=small_font, fill=(255, 255, 255))

    frame = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    
    # 3. Бар гучності
    vol_h = int(mic_volume * 150)
    cv2.rectangle(frame, (15, h-50), (35, h-200), (30, 30, 30), -1)
    cv2.rectangle(frame, (15, h-50), (35, h-50-vol_h), (0, 255, 255), -1)
    # МАЛЕНЬКА ОСЦИЛОГРАМА (справа від бара гучності)
    graph_x = 45  # Початкова точка X
    graph_y = h - 125 # Центральна лінія графіка по Y
    
    for i in range(1, len(audio_history)):
        # Малюємо лінії між точками історії
        pt1 = (graph_x + (i-1) * 3, int(graph_y - (audio_history[i-1] * 40)))
        pt2 = (graph_x + i * 3, int(graph_y - (audio_history[i] * 40)))
        cv2.line(frame, pt1, pt2, (0, 255, 255), 1, cv2.LINE_AA)
    
    return frame

# --- ЛОГІКА СЛУХАННЯ ---
def listen():
    global USER_SPEECH, mic_monitor_active
    r = sr.Recognizer()
    r.energy_threshold = 150 
    try:
        with sr.Microphone() as source:
            mic_monitor_active = False 
            r.adjust_for_ambient_noise(source, duration=0.3)
            print("--- ОЛЕНА СЛУХАЄ ---")
            audio = r.listen(source, timeout=10, phrase_time_limit=8)
            text = r.recognize_google(audio, language="uk-UA").lower()
            
            # ЦЕЙ РЯДОК ВАЖЛИВИЙ: він виводить текст на екран миттєво
            globals()['USER_SPEECH'] = text 
            mic_monitor_active = True
            return text
    except:
        mic_monitor_active = True
        return ""

def interrogation():
    global PHASE, USER_SPEECH
    
    PHASE = "СИНХРОНІЗАЦІЯ"
    speak("Едуарде, я на зв'язку. Протокол активації?")
    
    # Чекаємо команду "поїхали" або схожі
    ans = listen()
    
    triggers = ["поїхали", "поїхав", "так", "готов", "давай", "go"]
    if any(word in ans for word in triggers):
        PHASE = "АКТИВНЕ СПОСТЕРЕЖЕННЯ"
        speak("Доступ отримано. Едуарде ви змогли розпочати співбесіду. Яку гру ти обереш ?")
        
        # Чекаємо розповідь для Gemini
        ans_long = listen()
        
        if len(ans_long) > 2:
            PHASE = "ЗАПИТ ДО ЯДРА..."
            try:
                prompt = f"Ти Агент Олена, саркастичний ШІ. Відповідай різко і швидко. Проаналізуй: {ans_long}"
                response = client.models.generate_content(model=CURRENT_MODEL, contents=prompt)
                
                PHASE = "ВЕРДИКТ ОЛЕНИ"
                speak(response.text)
                # Даємо 5 секунд, щоб текст не зник миттєво
                time.sleep(5) 
            except:
                speak("Помилка зв'язку.")
    else:
        PHASE = "БРАКУЄ ДОКАЗІВ"
        speak("Я вас не зрозуміла. Спробуйте ще раз чіткіше.")
    
    time.sleep(2)
    PHASE = "ОЧІКУВАННЯ"
    USER_SPEECH = ""

# --- ЗАПУСК ---
# 1. Запускаємо аудіо-монітор
threading.Thread(target=audio_volume_monitor, daemon=True).start()
# 1. Спершу ініціалізуємо голос, щоб Олена могла говорити відразу
print("--- СИСТЕМА: ІНІЦІАЛІЗАЦІЯ Bivium Veri AI ---")

# 2. Голосове оголошення про запуск (виконуємо в окремому потоці, щоб не гальмувати камеру)
def welcome_announcement():
    time.sleep(1) # Невелика пауза для стабілізації аудіо-двигуна
    speak("Система Bivium Veri AI активована. Агент Олена готова до роботи.")

threading.Thread(target=welcome_announcement, daemon=True).start()

# 2. ВКЛЮЧАЄМО КАМЕРУ (Ось тут була твоя помилка!)
cap = cv2.VideoCapture(0)

# 3. ОСНОВНИЙ ЦИКЛ
while True:
    ret, frame = cap.read()
    if not ret: 
        break
    
    frame = cv2.flip(frame, 1)
    key = cv2.waitKey(1) & 0xFF

    if key == ord('s'):
        threading.Thread(target=interrogation, daemon=True).start()
    elif key == ord('r'):
        PHASE = "ОЧІКУВАННЯ"
        USER_SPEECH = ""
        STRESS_LEVEL = 0
        speak("Систему перезавантажено.")
    elif key == ord('x') or key == 27:
        break
    elif key in [ord('1'), ord('2'), ord('3')]:
        if chr(key) in MODELS:
            CURRENT_MODEL = MODELS[chr(key)]
            print(f"Модель: {CURRENT_MODEL}")

    frame = draw_ui(frame)
    cv2.imshow('Agent Elena - Bivium Veri', frame)

cap.release()
cv2.destroyAllWindows()